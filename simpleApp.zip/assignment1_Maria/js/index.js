

//Function to set Timer 

        setInterval(myTimer, 1000);
        function myTimer() {
        const d = new Date();
        document.getElementById('demo').innerHTML = d.toLocaleTimeString();
        }


//function to display the image of profile (Don't works)

        function myImage(){                       
          //  img.src = src1; //Cargamos la imagen de Isco (imagen1) al atributo "img.src".
           $('#foto').attr("src=../img/maria3.JPG"); //Añadimos la imagen "img" al id "#imagen".    
           // console.log("A ver si sale la imagen: ");
        }

        function myfunction1(value){
                console.log("Hello there, How are you today?");
            }   
        //    setTimeout(myfunction1, 4000);
            setTimeout(myImage, 9000);

         




